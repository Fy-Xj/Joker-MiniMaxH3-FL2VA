import json
import logging
import os
import sys
import time
from collections import OrderedDict

import infinicore
import numpy as np
from infinilm.base_config import BaseConfig
from infinilm.cache import PagedKVCacheConfig, StaticKVCacheConfig
from infinilm.distributed import DistConfig
from infinilm.infer_engine import GenerationConfig, InferEngine
from infinilm.llm.llm import LLM
from infinilm.llm.sampling_params import SamplingParams
from infinilm.modeling_utils import load_model_state_dict_by_file
from infinilm.moe_config import configure_moe_ep_backend
from infinilm.processors import AutoInfinilmProcessor
from tqdm import tqdm

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../python"))


DATA_TYPE_BYTES = {
    "bfloat16": 2,
    "float16": 2,
    "float32": 4,
}

_PAGED_KV_BLOCK_SIZE = 256
_WARMUP_DECODE_LEN = 5

# Maps model_type to its specific config key normalization rules.
# Each rule maps a standard key (e.g., "head_dim") to either:
#   - A string: representing the model-specific key name for direct mapping.
#   - A callable: a function that takes the config dict and computes the derived value.
_CONFIG_KEY_MAP = {
    "chatglm": {
        "num_key_value_heads": "multi_query_group_num",
        "num_hidden_layers": "num_layers",
        "head_dim": "kv_channels",
    },
    "baichuan": {
        "num_key_value_heads": "num_attention_heads",
        "head_dim": lambda cfg: cfg["hidden_size"] // cfg["num_attention_heads"],
    },
}


def _normalize_config(config, model_type):
    """
    Normalize model config to standard keys.

    Applies model-specific key mappings and derived computations defined in
    _CONFIG_KEY_MAP. Standard keys already present in the original config
    will not be overwritten.
    """
    normalized = dict(config)

    if "text_config" in normalized:
        normalized = normalized["text_config"]

    key_map = _CONFIG_KEY_MAP.get(model_type)

    if not key_map:
        return normalized

    for std_key, rule in key_map.items():
        # Skip if the standard key already exists in the original config
        if std_key in normalized:
            continue

        # Rule is a string: perform a direct key remapping
        if isinstance(rule, str):
            if rule in normalized:
                normalized[std_key] = normalized[rule]

        # Rule is a callable: compute the derived value dynamically
        elif callable(rule):
            try:
                normalized[std_key] = rule(normalized)
            except (KeyError, ZeroDivisionError, TypeError):
                # Silently skip if dependencies are missing or computation fails
                pass

    return normalized


# BATCH_SIZES = [1, 4, 8, 16, 32, 64, 128]
# INPUT_LENS = [32, 256, 1024, 4096]
# OUTPUT_LENS = [256, 1024, 4096]


def read_json_file(file_path):
    """Load and return JSON content from file_path."""
    with open(file_path, "r") as file:
        return json.load(file)


def get_test_cases(
    model_path: str,
    batch_size_list: list[int],
    input_len_list: list[int],
    output_len_list: list[int],
    use_mla: bool = False,
):
    model_path = os.path.expanduser(model_path)

    """Generate cases ordered by ascending KV cache memory usage."""
    # Load model config to derive attention dimensions
    config = read_json_file(os.path.join(model_path, "config.json"))
    model_type = config.get("model_type", "")
    config = _normalize_config(config, model_type)
    if model_type == "mamba":
        config.setdefault("num_hidden_layers", config.get("n_layer", 1))
        config.setdefault("num_key_value_heads", 1)
        config.setdefault("head_dim", config.get("state_size", 16))
    head_dim = config.get("head_dim")
    if head_dim is None:
        head_dim = config.get("hidden_size") // config.get("num_attention_heads")
    # KV heads and layers drive cache size. DeepSeek MLA stores a single KV head
    # with latent K and V dimensions instead of the regular per-head K/V cache.
    if use_mla and model_type == "deepseek_v2":
        num_key_value_heads = 1
        head_dim = config["kv_lora_rank"] * 2 + config["qk_rope_head_dim"]
    else:
        num_key_value_heads = config.get("num_key_value_heads")
    num_hidden_layers = config.get("num_hidden_layers")

    # Enumerate all batch/input/output combinations and compute KV cache size
    case_list = []
    for batch_size in batch_size_list:
        for input_len in input_len_list:
            for output_len in output_len_list:
                for data_type in ["bfloat16"]:
                    data_type_bytes = DATA_TYPE_BYTES[data_type]

                    total_seq_len = input_len + output_len
                    kvcache_memory_bytes = (
                        data_type_bytes
                        * (batch_size * total_seq_len * num_key_value_heads * head_dim)
                        * num_hidden_layers
                    )
                    kvcache_memory_gb = kvcache_memory_bytes / (1024 * 1024 * 1024)

                    case_list.append(
                        {
                            "idx": len(case_list),
                            "batch_size": batch_size,
                            "input_len": input_len,
                            "output_len": output_len,
                            "data_type": data_type,
                            "kvcache_memory": round(kvcache_memory_gb, 3),
                        }
                    )

    # Sort by KV cache size and wrap in OrderedDict with index keys
    case_dict = OrderedDict(
        (idx, case)
        for idx, case in enumerate(
            sorted(case_list, key=lambda case: case["kvcache_memory"])
        )
    )

    return case_dict


prompt_path = (
    "examples/bench_prompt.md"
    if os.path.isfile("examples/bench_prompt.md")
    else "InfiniLM/examples/bench_prompt.md"
)
with open(prompt_path, "r") as f:
    prompt = f.read()


def repeat_prompt(input_ids: list[int], target_length: int):
    num = len(input_ids)
    repeat_times = (target_length + num - 1) // num
    return (input_ids * repeat_times)[:target_length]


def split_benchmark_prompt_ids(tokenizer, input_content: str, prompt_text: str):
    """Split a rendered prompt into framing and repeatable user-content tokens."""
    prefix_text, separator, suffix_text = input_content.partition(prompt_text)
    if not separator:
        raise ValueError("The chat template did not preserve the benchmark prompt text")

    input_ids = tokenizer.encode(input_content)
    prefix_ids = tokenizer.encode(prefix_text)
    suffix_ids = tokenizer.encode(suffix_text, add_special_tokens=False)
    suffix_start = len(input_ids) - len(suffix_ids) if suffix_ids else len(input_ids)

    if input_ids[: len(prefix_ids)] != prefix_ids:
        raise ValueError("Unable to identify the tokenized chat-template prefix")
    if suffix_ids and input_ids[suffix_start:] != suffix_ids:
        raise ValueError("Unable to identify the tokenized chat-template suffix")

    return prefix_ids, input_ids[len(prefix_ids) : suffix_start], suffix_ids


def build_benchmark_prompt_ids(processor, tokenizer, prompt_text: str):
    """Tokenize a normalized chat prompt while keeping its framing separate."""
    prompt_text = prompt_text.strip()
    if not prompt_text:
        raise ValueError("The benchmark prompt must not be empty")

    input_content = processor.apply_chat_template(
        conversation=[{"role": "user", "content": prompt_text}],
        add_generation_prompt=True,
        tokenize=False,
    )
    return split_benchmark_prompt_ids(tokenizer, input_content, prompt_text)


def build_multimodal_benchmark_inputs(
    processor,
    tokenizer,
    prompt_text: str,
    image_path: str,
):
    """Prepare one image prompt while keeping its trailing text resizable."""
    from PIL import Image

    prompt_text = prompt_text.strip()
    if not prompt_text:
        raise ValueError("The benchmark prompt must not be empty")

    conversation = [
        {
            "role": "user",
            "content": [
                {"type": "image_url", "image_url": {"url": image_path}},
                {"type": "text", "text": prompt_text},
            ],
        }
    ]
    input_content = processor.apply_chat_template(
        conversation=conversation,
        add_generation_prompt=True,
        tokenize=False,
    )
    _, content_ids, suffix_ids = split_benchmark_prompt_ids(
        tokenizer, input_content, prompt_text
    )

    with Image.open(image_path) as image:
        processed_inputs = processor(
            [input_content],
            images=[[image.convert("RGB")]],
            return_tensors="pt",
        )

    processed_ids = processed_inputs["input_ids"][0].tolist()
    trailing_ids = content_ids + suffix_ids
    if not trailing_ids or processed_ids[-len(trailing_ids) :] != trailing_ids:
        raise ValueError(
            "Unable to identify user text after multimodal prompt processing"
        )

    prefix_ids = processed_ids[: -len(trailing_ids)]
    return (prefix_ids, content_ids, suffix_ids), processed_inputs


def cli_option_is_set(option: str):
    return any(
        argument == option or argument.startswith(f"{option}=")
        for argument in sys.argv[1:]
    )


def resize_benchmark_prompt(
    prefix_ids: list[int],
    content_ids: list[int],
    suffix_ids: list[int],
    target_length: int,
):
    """Resize only user content so the assistant generation suffix remains intact."""
    framing_length = len(prefix_ids) + len(suffix_ids)
    if target_length < framing_length:
        raise ValueError(
            f"input_len={target_length} is shorter than the chat framing "
            f"({framing_length} tokens)"
        )

    content_length = target_length - framing_length
    if content_length and not content_ids:
        raise ValueError(
            "Cannot fill the benchmark input because user content is empty"
        )

    return prefix_ids + repeat_prompt(content_ids, content_length) + suffix_ids


def convert_multimodal_inputs(model, processor, processed_inputs):
    """Convert one image into reusable low-level input tensors."""
    if processed_inputs is None:
        return {}

    if model.model_type == "videonsa":
        import torch

        pixel_values = processed_inputs.get("pixel_values")
        image_bound = processed_inputs.get("image_bound")
        image_grid_thw = processed_inputs.get("image_grid_thw")
        if pixel_values is None or image_bound is None or image_grid_thw is None:
            raise ValueError("VideoNSA image preprocessing returned incomplete inputs")

        valid_bounds = image_bound[0]
        valid_bounds = valid_bounds[valid_bounds[:, 1] > valid_bounds[:, 0]]
        if len(valid_bounds) != len(image_grid_thw):
            raise ValueError(
                "VideoNSA image token ranges do not match the preprocessed images"
            )

        expected_patches = sum(int(grid.prod().item()) for grid in image_grid_thw)
        if len(pixel_values) != expected_patches:
            raise ValueError("VideoNSA image patch count does not match image_grid_thw")

        pixel_dtype = getattr(processor, "pixel_values_dtype", torch.bfloat16)
        return {
            "pixel_values": infinicore.from_torch(
                pixel_values.to(dtype=pixel_dtype).contiguous()
            ),
            "image_bound": infinicore.from_torch(
                valid_bounds.unsqueeze(0).to(torch.int64).contiguous()
            ),
            "tgt_sizes": infinicore.from_torch(
                image_grid_thw.to(torch.int64).contiguous()
            ),
        }

    if model.model_type in {"qwen3_5", "qwen3_5_moe"}:
        import torch

        pixel_values = processed_inputs.get("pixel_values")
        image_grid_thw = processed_inputs.get("image_grid_thw")
        image_bound = processed_inputs.get("image_bound")
        if pixel_values is None or image_grid_thw is None or image_bound is None:
            raise ValueError("Qwen3.5 image preprocessing returned incomplete inputs")

        grids = processor._as_grid_list(image_grid_thw)
        bounds = processor._get_image_bounds(processed_inputs)
        if bounds is None or len(grids) != 1 or bounds.shape[0] != 1:
            raise ValueError("Expected exactly one preprocessed Qwen3.5 image")

        if isinstance(pixel_values, list):
            if len(pixel_values) != 1:
                raise ValueError("Expected exactly one Qwen3.5 pixel tensor")
            pixel_values = pixel_values[0]
        elif not isinstance(pixel_values, torch.Tensor):
            pixel_values = torch.as_tensor(pixel_values)

        pixel_dtype = getattr(processor, "pixel_values_dtype", None)
        if pixel_dtype is not None:
            pixel_values = pixel_values.to(dtype=pixel_dtype)

        return {
            "pixel_values": infinicore.from_torch(pixel_values.contiguous()),
            "image_grid_thw": infinicore.from_torch(
                grids[0].to(torch.int64).contiguous()
            ),
            "image_bound": infinicore.from_torch(
                bounds[0].to(torch.int64).contiguous()
            ),
        }

    if model.model_type != "minicpmv":
        raise ValueError(
            f"--image is not supported by bench.py for model_type={model.model_type!r}"
        )

    import torch

    pixel_values = processed_inputs["pixel_values"]
    image_bound = processed_inputs["image_bound"]
    tgt_sizes = processed_inputs["tgt_sizes"]
    if len(pixel_values) != 1:
        raise ValueError("Expected exactly one preprocessed benchmark image")

    all_pixel_values = [
        patch.flatten(end_dim=1).permute(1, 0)
        for patch_group in pixel_values
        for patch in patch_group
    ]
    pixel_values_tensor = torch.nn.utils.rnn.pad_sequence(
        all_pixel_values, batch_first=True, padding_value=0.0
    ).to(dtype=infinicore.utils.to_torch_dtype(model.dtype))
    image_count, length, _ = pixel_values_tensor.shape
    pixel_values_tensor = (
        pixel_values_tensor.permute(0, 2, 1)
        .reshape(image_count, 3, -1, length)
        .contiguous()
    )

    all_tgt_sizes = [
        tgt_size for tgt_size in tgt_sizes if isinstance(tgt_size, torch.Tensor)
    ]
    tgt_sizes_tensor = torch.vstack(all_tgt_sizes).to(torch.int64)

    max_ranges = max(len(bound) for bound in image_bound)
    bound_tensor = torch.zeros((len(image_bound), max_ranges, 2), dtype=torch.int64)
    for index, bound in enumerate(image_bound):
        if len(bound) > 0:
            bound_tensor[index, : len(bound), :] = bound

    return {
        "pixel_values": infinicore.from_torch(pixel_values_tensor),
        "image_bound": infinicore.from_torch(bound_tensor),
        "tgt_sizes": infinicore.from_torch(tgt_sizes_tensor),
    }


class TestModel:
    model: infinicore.nn.Module
    input_ids_list: list[int]

    def __init__(
        self,
        model_path,
        draft_model_path=None,
        num_draft_tokens=4,
        infini_device=infinicore.device("cpu", 0),
        tp=1,
        skip_load=False,
        cache_config=None,
        enable_graph=False,
        attn_backend="default",
        use_mla=False,
        weight_load_mode="async",
        pre_transpose=False,
        moe_ep_backend="disabled",
        moe_ep_size=1,
        pp=1,
        pp_stage=0,
        master_addr="127.0.0.1",
        master_port=29500,
        max_batch_size=1,
        max_tokens=512,
        num_blocks=512,
        block_size=256,
        max_cache_len=4096,
        temperature=1.0,
        top_p=1.0,
        top_k=1,
        use_legacy_moe=False,
        enable_prefix_caching=False,
        processor=None,
        tokenizer=None,
        prompt_token_segments=None,
        processed_multimodal_inputs=None,
        prompt_text=None,
    ) -> None:
        model_path = os.path.expanduser(model_path)
        self.draft_model_path = draft_model_path
        self.num_draft_tokens = num_draft_tokens
        self.model_path = model_path
        self.device_str = infini_device.type
        self.tp = tp
        self.cache_config = cache_config
        self.enable_graph = enable_graph
        self.attn_backend = attn_backend
        self.use_mla = use_mla
        self.weight_load_mode = weight_load_mode
        self.skip_load = skip_load
        self.enable_prefix_caching = enable_prefix_caching
        self.processor = processor
        self.tokenizer = tokenizer
        self.prompt_token_segments = prompt_token_segments
        self.processed_multimodal_inputs = processed_multimodal_inputs
        self.multimodal_inputs = {}
        self.pp = pp

        if pp > 1 and draft_model_path is not None:
            raise ValueError("pipeline-parallel speculative decoding is not supported")

        if draft_model_path is not None:
            if processed_multimodal_inputs is not None:
                raise ValueError("Draft-model benchmarks do not support --image")
            if self.processor is None:
                self.processor = AutoInfinilmProcessor.from_pretrained(model_path)
                self.tokenizer = self.processor.get_tokenizer()
            if self.prompt_token_segments is None:
                self.prompt_token_segments = build_benchmark_prompt_ids(
                    self.processor,
                    self.tokenizer,
                    prompt if prompt_text is None else prompt_text,
                )
            self.input_ids_list = [sum(self.prompt_token_segments, [])]
            self.model = None
            return

        if pp > 1:
            self.model = LLM(
                model_path=model_path,
                device=self.device_str,
                dtype=cfg.dtype,
                tensor_parallel_size=tp,
                pipeline_parallel_size=pp,
                pipeline_parallel_stage=pp_stage,
                master_addr=master_addr,
                master_port=master_port,
                moe_ep_backend=moe_ep_backend,
                moe_ep_size=moe_ep_size,
                cache_type="paged" if cache_config is not None else "static",
                max_batch_size=max_batch_size,
                max_tokens=max_tokens,
                num_blocks=num_blocks,
                block_size=block_size,
                max_cache_len=max_cache_len,
                temperature=temperature,
                top_p=top_p,
                top_k=top_k,
                enable_graph=enable_graph,
                attn_backend=attn_backend,
                use_mla=use_mla,
                weight_load_mode=weight_load_mode,
                skip_load=skip_load,
                use_legacy_moe=use_legacy_moe,
                enable_prefix_caching=enable_prefix_caching,
            )
            self.processor = self.model.engine.processor
            self.tokenizer = self.processor.get_tokenizer()
            input_content = self.processor.apply_chat_template(
                conversation=[{"role": "user", "content": prompt}],
                add_generation_prompt=True,
                tokenize=False,
            )
            self.input_ids_list = [self.tokenizer.encode(input_content)]
            return

        # ---------------------------------------------------------------------------- #
        #                        创建模型,
        # ---------------------------------------------------------------------------- #
        model = InferEngine(
            model_path,
            device=infini_device,
            distributed_config=DistConfig(
                tp,
                moe_ep_backend=moe_ep_backend,
                moe_ep_size=moe_ep_size,
            ),
            cache_config=cache_config,
            enable_graph_compiling=enable_graph,
            attention_backend=attn_backend,
            kv_cache_dtype=cfg.kv_cache_dtype,
            use_mla=use_mla,
            weight_load_mode=weight_load_mode,
            pre_transpose=pre_transpose,
        )
        self.multimodal_inputs = convert_multimodal_inputs(
            model, self.processor, processed_multimodal_inputs
        )

        # ---------------------------------------------------------------------------- #
        #                        加载权重
        # ---------------------------------------------------------------------------- #
        if not skip_load:
            load_model_state_dict_by_file(model, model_path, dtype=model.dtype)

        # ---------------------------------------------------------------------------- #
        #                        创建 tokenizer
        # ---------------------------------------------------------------------------- #
        if self.processor is None:
            self.processor = AutoInfinilmProcessor.from_pretrained(model_path)
            self.tokenizer = self.processor.get_tokenizer()

        # ---------------------------------------------------------------------------- #
        #                        token编码
        # ---------------------------------------------------------------------------- #
        if self.prompt_token_segments is None:
            self.prompt_token_segments = build_benchmark_prompt_ids(
                self.processor,
                self.tokenizer,
                prompt if prompt_text is None else prompt_text,
            )
        input_ids_list = [sum(self.prompt_token_segments, [])]

        self.model = model
        self.input_ids_list = input_ids_list
        self.draft_model_path = draft_model_path
        self.model_path = model_path
        self.device_str = infini_device.type
        self.tp = tp
        self.cache_config = cache_config
        self.enable_graph = enable_graph
        self.attn_backend = attn_backend
        self.use_mla = use_mla
        self.weight_load_mode = weight_load_mode
        self.skip_load = skip_load

    def get_multimodal_inputs(self, batch_size: int, prompt_ids=None):
        if not self.multimodal_inputs:
            return {}

        inputs = {
            "pixel_values": [self.multimodal_inputs["pixel_values"]] * batch_size,
            "image_bound": [self.multimodal_inputs["image_bound"]] * batch_size,
            "image_req_ids": list(range(batch_size)),
        }
        for key in ("tgt_sizes", "image_grid_thw"):
            if key in self.multimodal_inputs:
                inputs[key] = [self.multimodal_inputs[key]] * batch_size

        if self.model.model_type == "videonsa":
            if prompt_ids is None:
                raise ValueError("VideoNSA multimodal generation requires prompt IDs")
            position_ids = self.processor._prompt_mrope_positions(
                prompt_ids, self.processed_multimodal_inputs
            )
            if any(len(axis) != len(prompt_ids) for axis in position_ids):
                raise ValueError("VideoNSA mRoPE positions do not match the prompt")
            position_id_delta = (
                max(max(axis) for axis in position_ids) + 1 - len(prompt_ids)
            )
            inputs.update(
                prompt_position_ids=position_ids,
                position_id_delta=position_id_delta,
            )
        elif self.model.model_type in {"qwen3_5", "qwen3_5_moe"}:
            if prompt_ids is None:
                raise ValueError("Qwen3.5 multimodal generation requires prompt IDs")

            class BenchmarkRequest:
                processed_inputs = self.processed_multimodal_inputs

                def get_input_tokens(self):
                    return prompt_ids

            request = BenchmarkRequest()
            position_ids = self.processor._build_mrope_position_ids(
                request, 0, len(prompt_ids)
            )
            inputs.update(
                prompt_position_ids=position_ids.tolist(),
                position_id_delta=self.processor._compute_mrope_delta(request),
            )
        return inputs

    @property
    def uses_pipeline_parallel(self) -> bool:
        return self.pp > 1

    def close(self) -> None:
        if self.uses_pipeline_parallel:
            self.model.close()

    def run(
        self,
        batch_size: int,
        input_len: int,
        output_len: int,
        top_k=1,
        top_p=1.0,
        temperature=1.0,
    ):
        input_ids = resize_benchmark_prompt(
            *self.prompt_token_segments, target_length=input_len
        )
        input_ids_list = [input_ids] * batch_size

        # ---------------------------------------------------------------------------- #
        #                        自回归生成
        # ---------------------------------------------------------------------------- #
        if self.draft_model_path is not None or self.uses_pipeline_parallel:
            prompt_text = self.tokenizer.decode(input_ids, skip_special_tokens=False)
            llm = self.model
            if self.draft_model_path is not None:
                llm = LLM(
                    model_path=self.model_path,
                    draft_model_path=self.draft_model_path,
                    num_draft_tokens=self.num_draft_tokens,
                    device=self.device_str,
                    tensor_parallel_size=self.tp,
                    cache_type="paged" if self.cache_config is not None else "static",
                    max_batch_size=batch_size,
                    max_tokens=output_len,
                    temperature=temperature,
                    top_p=top_p,
                    top_k=top_k,
                    enable_graph=self.enable_graph,
                    attn_backend=self.attn_backend,
                    use_mla=self.use_mla,
                    weight_load_mode=self.weight_load_mode,
                    skip_load=self.skip_load,
                    enable_prefix_caching=self.enable_prefix_caching,
                )
            t1 = time.time()
            print("=================== start generate ====================")
            outputs = llm.generate(
                prompts=[prompt_text] * batch_size,
                sampling_params=SamplingParams(
                    max_tokens=output_len,
                    temperature=temperature,
                    top_p=top_p,
                    top_k=top_k,
                    ignore_eos=True,
                ),
                use_tqdm=False,
            )
            t2 = time.time()
            if cfg.verbose and not skip_load:
                if output_len <= 256:
                    for output in outputs:
                        print(output.outputs[0].text)
                else:
                    print(
                        f"[bench] output text omitted because output_len={output_len} > 256."
                    )
            print(f"total_time: {round((t2 - t1) * 1000, 2)} ms")
            return

        input_ids_infini = infinicore.from_list(input_ids_list, dtype=infinicore.int64)

        t1 = time.time()
        print("=================== start generate ====================")
        output_ids = self.model.generate(
            input_ids_infini,
            GenerationConfig(
                max_new_tokens=output_len,
                eos_token_id=[],
                top_k=top_k,
                top_p=top_p,
                temperature=temperature,
                stop_on_eos=False,
            ),
            **self.get_multimodal_inputs(batch_size, input_ids),
            _measure_and_log_time=True,
        )
        t2 = time.time()

        numpy_output_ids = np.array(
            [output_id.to_numpy()[0] for output_id in output_ids]
        )
        if not skip_load:
            display_output_ids = numpy_output_ids
            eos_positions = np.flatnonzero(
                np.isin(numpy_output_ids, self.model.eos_token_id)
            )
            if eos_positions.size > 0:
                first_eos = int(eos_positions[0])
                display_output_ids = numpy_output_ids[:first_eos]
                print(
                    f"[bench] representative output reached EOS after "
                    f"{first_eos} tokens; trailing benchmark tokens hidden."
                )
            print(self.tokenizer.decode(display_output_ids, skip_special_tokens=True))

        print(
            f"total_time: {round((t2 - t1) * 1000, 2)} ms",
        )


if __name__ == "__main__":
    cfg = BaseConfig()
    logging.basicConfig(
        level=getattr(logging, cfg.log_level.upper(), logging.INFO),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    benchmark_prompt = (
        cfg.prompt if cli_option_is_set("--prompt") or cfg.image else prompt
    ).strip()
    if not benchmark_prompt:
        raise ValueError("The benchmark prompt must not be empty")

    device_str = cfg.get_device_str(cfg.device)

    _PAGED_KV_BLOCK_SIZE = cfg.block_size
    # -------------------------------------------------------- #
    #             解析参数
    # -------------------------------------------------------- #
    model_path = cfg.model

    infini_device = infinicore.device(device_str, 0)

    tp = cfg.tp
    dp = cfg.dp
    moe_ep_backend, ep = configure_moe_ep_backend(
        tp, dp, cfg.ep, cfg.moe_ep_backend, model_path
    )
    print(f"MoE EP backend: {moe_ep_backend}  TP={tp}  DP={dp}  EP={ep}")

    skip_load = cfg.skip_load

    batch_size = cfg.batch_size
    input_len = cfg.input_len
    output_len = cfg.output_len
    enable_paged_attn = cfg.enable_paged_attn
    enable_graph = cfg.enable_graph
    attn_backend = cfg.attn

    if isinstance(batch_size, int):
        batch_size = [batch_size]

    if isinstance(input_len, int):
        input_len = [input_len]

    if isinstance(output_len, int):
        output_len = [output_len]

    processor = AutoInfinilmProcessor.from_pretrained(model_path)
    tokenizer = processor.get_tokenizer()
    processed_multimodal_inputs = None
    if cfg.image is not None:
        prompt_token_segments, processed_multimodal_inputs = (
            build_multimodal_benchmark_inputs(
                processor,
                tokenizer,
                benchmark_prompt,
                cfg.image,
            )
        )
    else:
        prompt_token_segments = build_benchmark_prompt_ids(
            processor,
            tokenizer,
            benchmark_prompt,
        )

    framing_length = len(prompt_token_segments[0]) + len(prompt_token_segments[2])
    invalid_input_lens = [length for length in input_len if length < framing_length]
    if invalid_input_lens:
        natural_input_len = sum(len(segment) for segment in prompt_token_segments)
        if cfg.image is not None:
            adjusted_input_lens = [
                natural_input_len if length < framing_length else length
                for length in input_len
            ]
            print(
                f"[bench] requested multimodal input_len={invalid_input_lens[0]} "
                f"is shorter than the fixed image/chat framing "
                f"({framing_length} tokens); using natural prompt length "
                f"{natural_input_len}."
            )
            input_len = adjusted_input_lens
        elif cli_option_is_set("--input-len"):
            raise ValueError(
                f"input_len={invalid_input_lens[0]} is shorter than the chat framing "
                f"({framing_length} tokens)"
            )
        else:
            print(
                f"[bench] default input_len={input_len[0]} is shorter than the chat "
                f"framing ({framing_length} tokens); using the natural prompt length "
                f"{natural_input_len}."
            )
            input_len = [natural_input_len]

    cases_dict = get_test_cases(
        model_path, batch_size, input_len, output_len, use_mla=cfg.use_mla
    )
    max_benchmark_batch_size = max(case["batch_size"] for case in cases_dict.values())
    max_benchmark_tokens = max(case["output_len"] for case in cases_dict.values())
    max_benchmark_cache_len = max(
        case["input_len"] + case["output_len"] for case in cases_dict.values()
    )
    # -------------------------------------------------------- #
    #             测试
    # -------------------------------------------------------- #
    if enable_paged_attn:
        paged_kv_block_size = _PAGED_KV_BLOCK_SIZE
        max_num_blocks = max(
            [
                (
                    (c_["input_len"] + c_["output_len"] + (paged_kv_block_size - 1))
                    // paged_kv_block_size
                )
                * c_["batch_size"]
                for _, c_ in cases_dict.items()
            ]
        )
        if cfg.warmup:
            warmup_case = next(iter(cases_dict.values()))
            warmup_num_blocks = (
                (
                    warmup_case["input_len"]
                    + _WARMUP_DECODE_LEN
                    + paged_kv_block_size
                    - 1
                )
                // paged_kv_block_size
                * warmup_case["batch_size"]
            )
            max_num_blocks = max(max_num_blocks, warmup_num_blocks)
        max_batch_size = max(batch_size)
        cache_config = PagedKVCacheConfig(
            max_num_blocks,
            paged_kv_block_size,
            max_batch_size=max_batch_size,
        )
    else:
        cache_config = None

    if enable_paged_attn and attn_backend == "default":
        attn_backend = "paged-attn"

    if cfg.pp > 1:
        cfg.max_batch_size = max_benchmark_batch_size
        cfg.max_new_tokens = max(
            max_benchmark_tokens,
            _WARMUP_DECODE_LEN if cfg.warmup else 0,
        )
        cfg.max_cache_len = max(
            max_benchmark_cache_len,
            next(iter(cases_dict.values()))["input_len"] + _WARMUP_DECODE_LEN
            if cfg.warmup
            else 0,
        )
        cfg.attn = attn_backend
        if enable_paged_attn:
            cfg.num_blocks = max_num_blocks

        if cfg.node_rank > 0:
            from infinilm.server.pipeline_worker import run_worker

            run_worker(cfg)
            raise SystemExit(0)

    test = TestModel(
        model_path,
        draft_model_path=cfg.draft_model,
        num_draft_tokens=cfg.num_draft_tokens,
        infini_device=infini_device,
        tp=tp,
        skip_load=skip_load,
        cache_config=cache_config,
        enable_graph=enable_graph,
        attn_backend=attn_backend,
        use_mla=cfg.use_mla,
        weight_load_mode=cfg.weight_load_mode,
        pre_transpose=cfg.pre_transpose,
        moe_ep_backend=moe_ep_backend,
        moe_ep_size=ep,
        pp=cfg.pp,
        pp_stage=cfg.node_rank,
        master_addr=cfg.master_addr,
        master_port=cfg.master_port,
        max_batch_size=max_benchmark_batch_size,
        max_tokens=max(
            max_benchmark_tokens,
            _WARMUP_DECODE_LEN if cfg.warmup else 0,
        ),
        num_blocks=max_num_blocks if enable_paged_attn else cfg.num_blocks,
        block_size=cfg.block_size,
        max_cache_len=max(
            max_benchmark_cache_len,
            next(iter(cases_dict.values()))["input_len"] + _WARMUP_DECODE_LEN
            if cfg.warmup
            else 0,
        ),
        temperature=cfg.temperature,
        top_p=cfg.top_p,
        top_k=cfg.top_k,
        use_legacy_moe=cfg.use_legacy_moe,
        enable_prefix_caching=False,
        processor=processor,
        tokenizer=tokenizer,
        prompt_token_segments=prompt_token_segments,
        processed_multimodal_inputs=processed_multimodal_inputs,
        prompt_text=benchmark_prompt,
    )

    # ---------------------------------------------------------------------------- #
    #                                Warmup
    # ---------------------------------------------------------------------------- #
    if cfg.warmup:
        warmup_steps = 1

        # warmup cache capacity
        warmup_case = next(iter(cases_dict.values()))
        warmup_batch = warmup_case["batch_size"]
        warmup_input_len = warmup_case["input_len"]
        warmup_decode_len = _WARMUP_DECODE_LEN

        print(
            f"\033[93m[warmup] batch={warmup_batch}, input_len={warmup_input_len}, "
            f"will prefill + {warmup_decode_len} decode steps\033[0m"
        )
        print("=================== warmup start ===================")

        if test.uses_pipeline_parallel:
            for _ in range(warmup_steps):
                test.run(
                    batch_size=warmup_batch,
                    input_len=warmup_input_len,
                    output_len=warmup_decode_len,
                    top_k=cfg.top_k,
                    top_p=cfg.top_p,
                    temperature=cfg.temperature,
                )
        else:
            if enable_paged_attn:
                warmup_num_blocks = (
                    (warmup_input_len + warmup_decode_len + paged_kv_block_size - 1)
                    // paged_kv_block_size
                ) * warmup_batch
                warmup_cache_config = PagedKVCacheConfig(
                    warmup_num_blocks,
                    paged_kv_block_size,
                    max_batch_size=warmup_batch,
                )
            else:
                warmup_cache_config = StaticKVCacheConfig(
                    max_batch_size=warmup_batch,
                    max_cache_len=warmup_input_len + warmup_decode_len,
                )

            test.model.reset_cache(warmup_cache_config)
            warmup_prompt_ids = resize_benchmark_prompt(
                *test.prompt_token_segments, target_length=warmup_input_len
            )
            warmup_ids = [warmup_prompt_ids] * warmup_batch
            input_ids_infini = infinicore.from_list(warmup_ids, dtype=infinicore.int64)

            for _ in range(warmup_steps):
                _ = test.model.generate(
                    input_ids_infini,
                    GenerationConfig(
                        max_new_tokens=warmup_decode_len,
                        temperature=cfg.temperature,
                        top_k=cfg.top_k,
                        top_p=cfg.top_p,
                        stop_on_eos=False,
                    ),
                    **test.get_multimodal_inputs(warmup_batch, warmup_prompt_ids),
                    _measure_and_log_time=False,
                )

        print("=================== warmup done ====================")

        # reset cache back to benchmark config
        if cache_config is not None and not test.uses_pipeline_parallel:
            test.model.reset_cache(cache_config)

    # ---------------------------------------------------------------------------- #
    #                                Warmup done
    # ---------------------------------------------------------------------------- #

    for idx, case in tqdm(cases_dict.items(), desc="Processing cases"):
        tqdm.write(f"\033[92mProcessing : {case}\033[0m")

        batch_size = case["batch_size"]
        input_len = case["input_len"]
        output_len = case["output_len"]

        if not test.uses_pipeline_parallel and not enable_paged_attn:
            # reset cache if static kvcache is used
            initial_capacity = input_len + output_len
            test.model.reset_cache(
                StaticKVCacheConfig(
                    max_batch_size=batch_size, max_cache_len=initial_capacity
                )
            )

        # run test one case
        test.run(
            batch_size=batch_size,
            input_len=input_len,
            output_len=output_len,
            top_k=cfg.top_k,
            top_p=cfg.top_p,
            temperature=cfg.temperature,
        )

    test.close()
